package kolekcje.sety.zadanie;

/**
 * 1) Stwórz set Stringów, dodaj jakies elementy, zrob tak zeby wyswietlic je w kolejnosci rosnacej
 * 2) Stwórz liste losowych liczb od 1 do 10, nastepnie zostaw tylko te unikatowe
 */
public class Main {
    public static void main(String[] args) {
    }
}
