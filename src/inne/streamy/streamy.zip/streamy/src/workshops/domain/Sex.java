package workshops.domain;

public enum Sex {
    MAN,
    WOMAN,
    OTHER
}
