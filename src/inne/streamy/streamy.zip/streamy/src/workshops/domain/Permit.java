package workshops.domain;

public enum Permit {
    TRANSFER,
    ORDER_HISTORY,
    LOAN,
    DEPOSIT
}
