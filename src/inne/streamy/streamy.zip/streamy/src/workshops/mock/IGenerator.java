package workshops.mock;

import java.util.List;

public interface IGenerator {

    List<?> generate();

}
