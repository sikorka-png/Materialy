package kolekcje.mapy.zadanie;

/**
 * 1) Napisz metode ktora pozwala dodawac do mapy kolejne wyrazy. Na koncu ma wyswietlic ile razy jaki element byl dodany
 * 2) napisz metode ktora przyjmuje Mape<Integer, String>, zamien wartosci ktorych klucze sa parzystych wartosci na słowo "parzyste"
 * 3) Napisz program, ktory symuluje dzialanie slownika polsko-angielskiego.
 * Przykładowy program:
 * Podaj slowko po Polsku: mama Slowko po Angielsku to mother.
 * Program dziala dopoki uzytkownik nie zrezygnuje
 * (cancel)
 * 4) W systemie przechowujemy nazwe klasy (szkolnej, np 1a, 2b) oraz listę osób
 * (same nazwiska jako Stringi) które uczeszczaja do klasy.
 *      1) Napisz metode ktora zwraca liste osob o najdluzszych nazwiskach z kazdej klasy
 *      2) Napisz metode która zwraca osobe o najdluzszym nazwisku ze wzystkich klas
 * 5) Napisz metode która zwraca osobe o najdluzszym nazwisku ze wzystkich klas
 */
public class Main {
    public static void main(String[] args) {

    }
}
