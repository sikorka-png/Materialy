
package zad1;


public class ListCreator { // Uwaga: klasa musi być sparametrtyzowana
}  
